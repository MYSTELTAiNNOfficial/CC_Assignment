import 'dart:convert';

import 'package:flutter_connect_api/shared/shared.dart';
import 'package:http/http.dart' as http;

part "rajaongkirservice.dart";
part of "shared.dart";

class Const{
  static String BASE_URL ="api.rajaongkir.com/";
  static String API = "8b5d2c01af6e8065ed2f96aba8ec0d63";
}